#ifndef FONCTION_H_INCLUDED	
#define FONCTION_H_INCLUDED
#include<gtk/gtk.h>

typedef struct date {
int jour; 
int mois;
int annee;
}date;
typedef struct produit{
char id[30];
char nom[100];
int qu;
date dajout;
date dexpiration;
char typep[40];

}produit ;

//fonction ajouter p
void ajout_p(produit p);
//fonction supprimer p
void supp_p(char identif[]);
//fonction modifier p
void modif_p(produit p);
//fonction qui verifie l'existence de produit dans le fichier
int verif_p(char identif[]);
void vider(GtkWidget *liste);
void affiche_produit(GtkWidget *liste,char file[]);
void cherche_p(char identif[]);
void repture_stock();
#endif

