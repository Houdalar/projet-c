#include <gtk/gtk.h>


void
on_supprimerom_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouterom_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chercherom_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_om__clicked                         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierom_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_deconnecterom_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour1om_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouter1om_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retour2om_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonret_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button12modif_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button13retour_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficherom_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_actualiser_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_chercherom5_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button1supomz_clicked               (GtkWidget      *objet_graphique,
                                        gpointer         user_data);



void
on_button1repom_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);
