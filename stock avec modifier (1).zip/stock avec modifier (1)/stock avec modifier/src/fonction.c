#include"fonction.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<gtk/gtk.h>
enum
{ 	
	nom,
	identifiant,
	quantite,
	joura,
	moisa,
	anneea,
	joure,
	moise,
	anneee,
	typeproduit,
	COLUMNS
};
void ajout_p(produit p)
{
	FILE *f=NULL;
	f=fopen("stock.txt","a");
		if (f!=NULL)
		{
			fprintf(f,"%s %s %d %d %d %d %d %d %d %s \n",p.nom,p.id,p.qu,p.dajout.jour,p.dajout.mois,p.dajout.annee,p.dexpiration.jour,p.dexpiration.mois,p.dexpiration.annee,p.typep);
			fclose(f);
		}
}
///////////////////////////////////
void supp_p(char identif[])
{
	produit p;
	FILE *f=NULL;
	FILE *a=NULL;
	f=fopen("stock.txt","r");
	a=fopen("tmp.txt","a");
	if (verif_p(identif)==1)
	{
		while(fscanf(f,"%s %s %d %d %d %d %d %d %d %s \n",p.nom,p.id,&p.qu,&p.dajout.jour,&p.dajout.mois,&p.dajout.annee,&p.dexpiration.jour,&p.dexpiration.mois,&p.dexpiration.annee,p.typep)!=EOF)
		{
			if (strcmp(identif,p.id)!=0)
			{
				fprintf(a,"%s %s %d %d %d %d %d %d %d %s \n",p.nom,p.id,p.qu,p.dajout.jour,p.dajout.mois,p.dajout.annee,p.dexpiration.jour,p.dexpiration.mois,p.dexpiration.annee,p.typep);
			}
		}
	}
	fclose(f);
	fclose(a);
	remove("stock.txt");
	rename("tmp.txt","stock.txt");
}


/////////////////////////
int verif_p(char identif[])
{



	FILE *f;
	produit p;
	f=fopen("stock.txt","r");
	if(f!=NULL)
	{
		while(fscanf(f,"%s %s %d %d %d %d %d %d %d %s \n",p.nom,p.id,&p.qu,&p.dajout.jour,&p.dajout.mois,&p.dajout.annee,&p.dexpiration.jour,&p.dexpiration.mois,&p.dexpiration.annee,p.typep)!=EOF)
		{
			if(strcmp(p.id,identif)==0)
				return 1;
		}
		fclose(f);
	}
	
	return (0);
}
//////////////////////////////////////////

void modif_p(produit p)
{

char ch1[20];
char ch2[20];
int n1;
int n2;
int n3;
int n4;
int n5;
int n6;
int n7;
char ch3[30];

	produit pr ;
	FILE *f=NULL;
	FILE *a=NULL;
	f=fopen("stock.txt","r");
	a=fopen("tmp.txt","a");
	
	
		if (f!=NULL)
		{
			while(fscanf(f,"%s %s %d %d %d %d %d %d %d %s \n",ch1,ch2,&n1,&n2,&n3,&n4,&n5,&n6,&n7,ch3)!=EOF)
			{
				if ((strcmp(p.id,ch2)!=0))
				{
					fprintf(a,"%s %s %d %d %d %d %d %d %d %s \n",ch1,ch2,n1,n2,n3,n4,n5,n6,n7,ch3);
				}
				else
				{
				        fprintf(a,"%s %s %d %d %d %d %d %d %d %s  \n",p.nom,p.id,p.qu,p.dajout.jour,p.dajout.mois,p.dajout.annee,p.dexpiration.jour,p.dexpiration.mois,p.dexpiration.annee,p.typep);
				     
				}
			}
		
		fclose(f);
		fclose(a);
		remove("stock.txt");
		rename("tmp.txt","stock.txt"); 
	}
}/*
void modif_p(produit p)
{
produit pr ;
FILE*f=NULL;
FILE*f1=NULL;
f=fopen("stock.txt","r");
f1=fopen("tmp.txt","w");
if(verif_p(p.id)==1)
{
 if (f==NULL || f1==NULL)
      return;
 else
 {
  while (fscanf(f,"%s %s %d %d %d %d %d %d %d %s \n",pr.nom,pr.id,pr.qu,pr.dajout.jour,pr.dajout.mois,pr.dajout.annee,pr.dexpiration.jour,pr.dexpiration.mois,pr.dexpiration.annee,pr.typep)!=EOF)
  {
    if(strcmp(pr.id,p.id)!=0)
    fprintf(f1,"%s %s %d %d %d %d %d %d %d %s \n",p.nom,p.id,p.qu,p.dajout.jour,p.dajout.mois,p.dajout.annee,p.dexpiration.jour,p.dexpiration.mois,p.dexpiration.annee,p.typep);
    else
    fprintf(f1,"%s %s %d %d %d %d %d %d %d %s \n",pr.nom,pr.id,pr.qu,pr.dajout.jour,pr.dajout.mois,pr.dajout.annee,pr.dexpiration.jour,pr.dexpiration.mois,pr.dexpiration.annee,pr.typep);			
  }
    
fclose(f);
fclose(f1);
remove ("stock.txt");
rename("tmp.txt" , "stock.txt");
 }
}
}*/
//////////////////////////////////////////////////////////////////////////////
void cherche_p(char identif[])
{
FILE *F,*f1;
produit p;
F = fopen ("stock.txt", "r");
f1=fopen("recherche.txt","a+");


  if (F!=NULL)
{
  while (fscanf (F, "%s %s %d %d %d %d %d %d %d %s \n",p.nom,p.id,&p.qu,&p.dajout.jour,&p.dajout.mois,&p.dajout.annee,&p.dexpiration.jour,&p.dexpiration.mois,&p.dexpiration.annee,p.typep) != EOF)
   {
    if (strcmp(p.id,identif)==0)
	fprintf(f1,"%s %s %d %d %d %d %d %d %d %s \n",p.nom,p.id,p.qu,p.dajout.jour,p.dajout.mois,p.dajout.annee,p.dexpiration.jour,p.dexpiration.mois,p.dexpiration.annee,p.typep);
   } 
   
}
fclose(f1);
fclose(F);	
}
///////////////////////////
void affiche_produit(GtkWidget *liste,char file[])
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	FILE *f;
	produit p;
	store=NULL;
	store=gtk_tree_view_get_model(liste);
	if(store==NULL)
	{

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("NOM",renderer,"text",nom,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		renderer=gtk_cell_renderer_text_new();

		column=gtk_tree_view_column_new_with_attributes("IDENTIFIANT",renderer,"text",identifiant,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		renderer=gtk_cell_renderer_text_new();

		column=gtk_tree_view_column_new_with_attributes("QUANTITE",renderer,"text",quantite,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		renderer=gtk_cell_renderer_text_new();

		column=gtk_tree_view_column_new_with_attributes("jour d'ajout",renderer,"text",joura,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		renderer=gtk_cell_renderer_text_new();

		column=gtk_tree_view_column_new_with_attributes("mois d'ajout",renderer,"text",moisa,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		renderer=gtk_cell_renderer_text_new();

		column=gtk_tree_view_column_new_with_attributes("annee d'ajout",renderer,"text",anneea,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		renderer=gtk_cell_renderer_text_new();

		column=gtk_tree_view_column_new_with_attributes("jour d'exp",renderer,"text",joure,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		renderer=gtk_cell_renderer_text_new();

		column=gtk_tree_view_column_new_with_attributes("mois d'exp",renderer,"text",moise,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		renderer=gtk_cell_renderer_text_new();

		column=gtk_tree_view_column_new_with_attributes("annee d'exp",renderer,"text",anneee,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		renderer=gtk_cell_renderer_text_new();

		column=gtk_tree_view_column_new_with_attributes("TYPE",renderer,"text",typeproduit,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	}
	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);
	f=fopen(file,"r");
	if (f==NULL) 
	{
	return;
	}
	else 
	{
	  
	  while (fscanf(f,"%s %s %d %d %d %d %d %d %d %s \n",p.nom,p.id,&p.qu,&p.dajout.jour,&p.dajout.mois,&p.dajout.annee,&p.dexpiration.jour,&p.dexpiration.mois,&p.dexpiration.annee,p.typep)!=EOF)
	  {
		gtk_list_store_append(store,&iter);
		gtk_list_store_set(store,&iter,nom,p.nom,identifiant,p.id,quantite,p.qu,joura,p.dajout.jour,moisa,p.dajout.mois,anneea,p.dajout.annee,joure,p.dexpiration.jour,moise,p.dexpiration.mois,anneee,p.dexpiration.annee,typeproduit,p.typep,-1);
	  }
	  fclose(f);
	  gtk_tree_view_set_model(GTK_TREE_VIEW(liste) , GTK_TREE_MODEL(store));
	  g_object_unref(store);
		}
}

/////////////////////////////////////////////////////////////////
void vider(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
produit p;
store=NULL;
FILE *f=NULL;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();	column=gtk_tree_view_column_new_with_attributes("NOM",renderer,"text",nom,NULL);			gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();	column=gtk_tree_view_column_new_with_attributes("IDENTIFIANT",renderer,"text",identifiant,NULL);			gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();			column=gtk_tree_view_column_new_with_attributes("QUANTITE",renderer,"text",quantite,NULL);			gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("jourd'ajout",renderer,"text",joura,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();

			column=gtk_tree_view_column_new_with_attributes("mois d'ajout",renderer,"text",moisa,NULL);
			gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
			renderer=gtk_cell_renderer_text_new();

			column=gtk_tree_view_column_new_with_attributes("annee d'ajout",renderer,"text",anneea,NULL);
			gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
			renderer=gtk_cell_renderer_text_new();

			column=gtk_tree_view_column_new_with_attributes("jour d'exp",renderer,"text",joure,NULL);
			gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
			renderer=gtk_cell_renderer_text_new();

			column=gtk_tree_view_column_new_with_attributes("mois d'exp",renderer,"text",moisa,NULL);
			gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
			renderer=gtk_cell_renderer_text_new();

			column=gtk_tree_view_column_new_with_attributes("annee d'exp",renderer,"text",anneee,NULL);
			gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
			renderer=gtk_cell_renderer_text_new();

			column=gtk_tree_view_column_new_with_attributes("TYPE",renderer,"text",typeproduit,NULL);
			gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	}
	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
}
//////////////////////////////////////////////////////////////////////
void repture_stock()
{
FILE *F,*f1;
produit p;
F = fopen ("stock.txt", "r");
f1=fopen("recherche.txt","a+");


  if (F!=NULL)
{
  while (fscanf (F, "%s %s %d %d %d %d %d %d %d %s \n",p.nom,p.id,&p.qu,&p.dajout.jour,&p.dajout.mois,&p.dajout.annee,&p.dexpiration.jour,&p.dexpiration.mois,&p.dexpiration.annee,p.typep) != EOF)
   {
    if (p.qu==0)
	fprintf(f1,"%s %s %d %d %d %d %d %d %d %s \n",p.nom,p.id,p.qu,p.dajout.jour,p.dajout.mois,p.dajout.annee,p.dexpiration.jour,p.dexpiration.mois,p.dexpiration.annee,p.typep);
   } 
   
}
fclose(f1);
fclose(F);	
}

