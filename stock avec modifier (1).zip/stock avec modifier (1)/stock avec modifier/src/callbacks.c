#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include<string.h>
#include <gtk/gtk.h>
#include "fonction.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <stdlib.h>

int x;
char types[3][50] = {
                         "produit",
                         "fruit/leg",
                         "viandes"
                     };




void
on_supprimerom_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *suupom;
suupom=create_suupom();
gtk_widget_show(suupom);
}


void
on_ajouterom_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *ajoutduproduit;
ajoutduproduit=create_ajoutduproduit();
gtk_widget_show(ajoutduproduit);

}


void
on_chercherom_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *stock;
stock=create_stock();
gtk_widget_show(stock);
}


void
on_om__clicked                         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *repture;
repture=create_repture();
gtk_widget_show(repture);
}


void
on_modifierom_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *modification;
modification=create_modification();
gtk_widget_show(modification);
}


void
on_deconnecterom_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *profilom;
profilom=lookup_widget(objet,"profilom");
gtk_widget_destroy(profilom);
}


void
on_retour1om_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *profilom;
GtkWidget *ajoutduproduit;
ajoutduproduit=lookup_widget(objet,"ajoutduproduit");
gtk_widget_destroy(ajoutduproduit);
profilom=lookup_widget(objet,"profilom");
profilom=create_profilom();
}

/////ajouter terminer avec succeé/////
void
on_ajouter1om_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *entrynp,*entryid;
GtkWidget *combobox1;
GtkWidget *jour,*mois,*annee,*jour1,*mois1,*annee1,*quantite;
GtkWidget *ajoutduproduit;
GtkWidget *idom,*nomom;
produit p;
int r=0;
char *markup;
const char *format="<b><span color='red'> \%s </span></b>";
entrynp=lookup_widget(objet_graphique,"entrynomom");
idom=lookup_widget(objet_graphique,"idominco");
nomom=lookup_widget(objet_graphique,"idnominco");
entryid=lookup_widget(objet_graphique,"entryidom");
combobox1=lookup_widget(objet_graphique,"comboboxentry1");
quantite=lookup_widget(objet_graphique,"spinbuttonom");
jour=lookup_widget(objet_graphique,"spinbuttonjo");
mois=lookup_widget(objet_graphique,"spinbuttonmo");
annee=lookup_widget(objet_graphique,"spinbuttonam");
jour1=lookup_widget(objet_graphique,"spinbutton12");
mois1=lookup_widget(objet_graphique,"spinbutton6");
annee1=lookup_widget(objet_graphique,"spinbutton7");
if(strcmp("",gtk_entry_get_text(GTK_ENTRY(entrynp)))==0)
	{
		char *markup=g_markup_printf_escaped(format,"saisir le nom");
		gtk_label_set_markup(GTK_LABEL(nomom),markup);
		g_free(markup);
		r++;
	}

strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(entrynp)));
if(strcmp("",gtk_entry_get_text(GTK_ENTRY(entryid)))==0)
	{
		char *markup=g_markup_printf_escaped(format,"saisir l'id");
		gtk_label_set_markup(GTK_LABEL(idom),markup);
		g_free(markup);
		r++;
	}
strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(entryid)));
p.qu=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(quantite));
strcpy(p.typep,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
p.dajout.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
p.dajout.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
p.dajout.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
p.dexpiration.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour1));
p.dexpiration.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois1));
p.dexpiration.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee1));
int verif=-1;
verif=verif_p(p.id);
if(verif==0&&r==0)
{
ajout_p(p);
}
if(verif==1)
{
char *markup=g_markup_printf_escaped(format,"id existe");
		gtk_label_set_markup(GTK_LABEL(idom),markup);
		g_free(markup);

}
}

void
on_retour2om_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *profilom;
GtkWidget *stock;
stock=lookup_widget(objet,"stock");
gtk_widget_destroy(stock);
profilom=lookup_widget(objet,"profilom");
profilom=create_profilom();
}


void
on_buttonret_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *profilom;
GtkWidget *modification;
modification=lookup_widget(objet,"modification");
gtk_widget_destroy(modification);
profilom=lookup_widget(objet,"profilom");
profilom=create_profilom();
}


void
on_button12modif_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
produit pr;
GtkWidget *label37,*entrynp,*entryid;
GtkWidget *combobox1;
GtkWidget *jour,*mois,*annee,*jour1,*mois1,*annee1,*quantite;
GtkWidget *ajoutduproduit;
GtkWidget *viandes,*produit,*fruit_leg;


viandes=lookup_widget(objet_graphique,"viandes");
produit=lookup_widget(objet_graphique,"produit");
fruit_leg=lookup_widget(objet_graphique,"fruit_leg");

entrynp=lookup_widget(objet_graphique,"entry5nom");
entryid=lookup_widget(objet_graphique,"entry4id");
quantite=lookup_widget(objet_graphique,"spinbutton8om");
jour=lookup_widget(objet_graphique,"spinbutton9om");
mois=lookup_widget(objet_graphique,"spinbutton10om");
annee=lookup_widget(objet_graphique,"spinbutton11om");
jour1=lookup_widget(objet_graphique,"spinbutton12om");
mois1=lookup_widget(objet_graphique,"spinbutton13om");
annee1=lookup_widget(objet_graphique,"spinbutton14om");



strcpy(pr.nom,gtk_entry_get_text(GTK_ENTRY(entrynp)));
strcpy(pr.id,gtk_entry_get_text(GTK_ENTRY(entryid)));
pr.qu=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(quantite));



pr.dajout.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
pr.dajout.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
pr.dajout.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
pr.dexpiration.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour1));
pr.dexpiration.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois1));
pr.qu=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(quantite));
pr.dexpiration.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee1));


if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(viandes)))
strcpy(pr.typep,"viandes");
else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(fruit_leg)))
strcpy(pr.typep,"fruit_legumes");
else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(produit)))
strcpy(pr.typep,"produit_alimentaires");



if (verif_p(pr.id)==0)
{
label37=lookup_widget(objet_graphique,"messgaemodificationom");
gtk_label_set_text(GTK_LABEL(label37),"L'identifiant n'existe pas ");
}
else
{
label37=lookup_widget(objet_graphique,"messgaemodificationom");
gtk_label_set_text(GTK_LABEL(label37),"Modification fait avec succee");
modif_p(pr);
}
}


void
on_button13retour_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *profilom;
GtkWidget *repture;
repture=lookup_widget(objet,"repture");
gtk_widget_destroy(repture);
profilom=lookup_widget(objet,"profilom");
profilom=create_profilom();
}


void
on_afficherom_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ajoutduproduit;
GtkWidget *stock;
GtkWidget *treeview1;
ajoutduproduit=lookup_widget(objet,"ajoutduproduit");
gtk_widget_destroy(ajoutduproduit);
stock=lookup_widget(objet,"stock");
stock=create_stock();
gtk_widget_show(stock);
treeview1=lookup_widget(stock,"treeview1");
affiche_produit(treeview1,"stock.txt");
}


/*void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

GtkTreeIter iter;
gchar *nom;
gchar *identifiant;
gchar *quantite;
gchar *joura;
gchar *moisa;
gchar *anneea;
gchar *joure;
gchar *moise;
gchar *anneee;
gchar *typeproduit;
char identif[200];

GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,nom,1,identifiant,2,quantite,3,joura,4,moisa,5,anneea,6,joure,7,moise,8,anneee,9,typeproduit, -1);
strcpy(identif,identifiant);
strcpy(identif,identifiant);
supp_p(identif);
affiche_produit(treeview,"stock.txt");
}
}
*/

/*void
on_actualiser_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *stock,*w1;
GtkWidget *treeview1;

w1= lookup_widget(objet_graphique,"stock");
stock=create_stock();
gtk_widget_show(stock);
gtk_widget_hide(w1);
treeview1=lookup_widget(stock,"treeview1");

vider(treeview1);
affiche_produit(treeview1,"stock.txt");

}
*/

void
on_chercherom5_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
char id1[20];
GtkWidget *idrecherche,*stock,*treeview;
idrecherche=lookup_widget(objet,"entry1");
stock=lookup_widget(objet,"stock");
treeview=lookup_widget(stock,"treeview1");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(idrecherche)));
if(strcmp(id1,"")==0)
	affiche_produit(treeview,"stock.txt");
else
	{
	cherche_p(id1);
	affiche_produit(treeview,"recherche.txt");
	remove("recherche.txt");
	}
}


void
on_button1supomz_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *entryomid1,*label37;
char identif[200];
entryomid1=lookup_widget(objet_graphique,"entry2001idom");
strcpy(identif,gtk_entry_get_text(GTK_ENTRY(entryomid1)));
if (verif_p(identif)==0)
{
label37=lookup_widget(objet_graphique,"label39om2001");
gtk_label_set_text(GTK_LABEL(label37),"on arrive pas a trouver cet identifiant verifier encore une fois");
}
else
{
supp_p(identif);
label37=lookup_widget(objet_graphique,"label39om2001");
gtk_label_set_text(GTK_LABEL(label37),"Suppression fait avec succee");
}
}




void
on_button1repom_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *repture,*treeview;
repture=lookup_widget(objet,"repture");
treeview=lookup_widget(repture,"treeview2om");

	repture_stock();
	affiche_produit(treeview,"recherche.txt");
	remove("recherche.txt");
	
}

